package wrappers;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

public class NewTest {
  @Test
  public void f() {
  }
  @BeforeMethod
  public void beforeMethod() {
  }

}
