package utils;

import java.io.File;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Reporter {
	
	static ExtentReports report;
	static ExtentTest test;

	// Create Html Report
	public void createReport() {
		report = new ExtentReports("./reports/result.html", false);
		report.loadConfig(new File("./extent.xml"));
	}

	// Create Test case
	public void createTestReport(String testcaseName, String desc,
								 String author, String category) {

		// Step 2: Create testcase 
		test = report.startTest(testcaseName, desc);

		// Step 2: Author, category
		test.assignAuthor(author);
		test.assignCategory(category);

	}

	// Log the steps
	public void logStep(String status, String desc) {
		if(status.equalsIgnoreCase("pass"))
			test.log(LogStatus.PASS, desc);
		else if(status.equalsIgnoreCase("fail")) {
			test.log(LogStatus.FAIL, desc);
			throw new RuntimeException();
		}else if(status.equalsIgnoreCase("warn"))
			test.log(LogStatus.WARNING, desc);
	}

	// End the testcase
	public void closeTestReport() {
		report.endTest(test);	
	}
	
	// Save the report
	public void saveReport() {
		report.flush();
	}
}
