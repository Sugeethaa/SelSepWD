package tests;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import utils.DataInputProvider;
import wrappers.LeaftapsWrappers;


public class CreateLead extends LeaftapsWrappers {

	// packagename.classname.methodname
	@Test(dataProvider = "fetchExcelData")
	public void createLead(String companyName, String firstName, String lastName) {

		clickByLink("CRM/SFA");
		clickByXpath("//*[text()='Leads']");
		clickByLink("Create Lead");
		enterById("createLeadForm_companyName", companyName);
		enterById("createLeadForm_firstName", firstName);
		enterById("createLeadForm_lastName", lastName);

	}

	
	// Read the create lead from excel sheet
	@DataProvider(name = "fetchExcelData")
	public Object[][] getExcelData() throws InvalidFormatException, IOException {
		DataInputProvider re = new DataInputProvider();
		Object[][] data = re.readExcel("CreateLead");
		return data;
	}

}