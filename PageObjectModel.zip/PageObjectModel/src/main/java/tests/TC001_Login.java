package tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.LoginPage;
import wrappers.LeaftapsWrappers;

public class TC001_Login extends LeaftapsWrappers{
	
	@BeforeClass
	public void beforeClass() {
		excelName="TC001";
		testName="Login";
		testDescription="Login to leaftaps";
		author = "Babu";
		category = "Smoke";
	}
	
	
	@Test(dataProvider="fetchExcelData")
	public void login(String username, String password) {
		
		new LoginPage()
	    .typeUserName(username)
		.typePassword(password)
		.clickLogin()
		.clickLogout();
		
		
	}

}
