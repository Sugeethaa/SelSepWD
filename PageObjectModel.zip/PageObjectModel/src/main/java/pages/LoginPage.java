package pages;

import wrappers.LeaftapsWrappers;

public class LoginPage extends LeaftapsWrappers {
	
	public LoginPage() {
		if(!verifyTitle("Opentaps Open Source ERP + CRM")) {
			logStep("FAIL", "This is not Login Page");
		}		
    }
	
	public LoginPage typeUserName(String data) {
		enterById("username", data);
		return this;
	}
	
	public LoginPage typePassword(String data) {
		enterById("password", data);
		return this;
	}
	
	public HomePage clickLogin() {
		//clickByClassName("decorativeSubmit");
		clickByXpath("//input[@value='Login']");
		return new HomePage();
	}
	
	
	
	
	
	
	
	
}
