package pages;

import wrappers.LeaftapsWrappers;

public class HomePage extends LeaftapsWrappers {
	
	public HomePage() {
		if(!verifyTitle("Opentaps Open Source ERP + CRM")) {
			logStep("FAIL", "This is not Home Page");
		}		
    }
	
	
	public LoginPage clickLogout() {
		clickByClassName("decorativeSubmit");
		return new LoginPage();
	}
	
	
	
	
	
	
	
	
}
